#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
typedef uint64_t u64; typedef uint32_t u32; typedef uint8_t u8;
#define MOD 2013265921u
#define ROOT 31u
static u32 modpow(u32 a,u64 e){u64 r=1,b=a;while(e){if(e&1)r=r*b%MOD;b=b*b%MOD;e>>=1;}return (u32)r;}
static void ntt(u32*a,size_t n,int inv){
 for(size_t i=1,j=0;i<n;i++){size_t bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j){u32 t=a[i];a[i]=a[j];a[j]=t;}}
 for(size_t len=2;len<=n;len<<=1){u32 wlen=modpow(ROOT,(MOD-1)/len);if(inv)wlen=modpow(wlen,MOD-2);
  for(size_t i=0;i<n;i+=len){u64 w=1;for(size_t k=0;k<len/2;k++){u32 u=a[i+k],v=(u32)(a[i+k+len/2]*w%MOD);
   u32 x=u+v; if(x>=MOD)x-=MOD; u32 y=(u>=v)?u-v:u+MOD-v; a[i+k]=x;a[i+k+len/2]=y; w=w*wlen%MOD;}}}
 if(inv){u32 in=modpow((u32)n,MOD-2);for(size_t i=0;i<n;i++)a[i]=(u32)((u64)a[i]*in%MOD);}}
int main(){
 size_t N=64, sz=128;
 u8 ip[65]; memset(ip,0,65);
 for(int i=2;i<=64;i++){int pr=1;for(int d=2;d*d<=i;d++)if(i%d==0)pr=0;if(pr)ip[i]=1;}
 u32*A=calloc(sz,4),*B=calloc(sz,4);
 for(u64 i=0;i<=N;i++){A[i]=ip[i];B[i]=ip[i];}
 ntt(A,sz,0);ntt(B,sz,0);for(size_t i=0;i<sz;i++)A[i]=(u32)((u64)A[i]*B[i]%MOD);ntt(A,sz,1);
 for(int n=10;n<=20;n+=2){u64 ord=0;for(int p=2;p<=n;p++)if(ip[p]&&ip[n-p])ord++;
  printf("n=%d ntt=%u brute_ord=%llu\n",n,A[n],(unsigned long long)ord);}
 return 0;}
